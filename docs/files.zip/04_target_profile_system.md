# Prospector — Target Profile System

## What Is a Target Profile?

A target profile is a configuration file that tells Prospector what kind of businesses to look for. It is the only thing you need to change to run a completely different search.

Profiles are saved as individual files. You can have as many as you want. You call one by name when you run Prospector.

---

## Profile Parameters

### Required

| Parameter | Description | Example |
|-----------|-------------|---------|
| `name` | Profile identifier | `"maribor_wood"` |
| `keywords` | What to search for | `["woodworking", "carpenter", "lesarstvo"]` |
| `locations` | Where to search | `["Maribor", "Slovenija"]` |

### Optional Filters

| Parameter | Description | Example |
|-----------|-------------|---------|
| `require_website` | Only include businesses with a website | `true` |
| `require_phone` | Only include businesses with a phone number | `false` |
| `exclude_keywords` | Skip businesses with these words in name | `["hobi", "hobby"]` |
| `min_reviews` | Minimum Google Maps review count | `5` |
| `language` | Expected website language | `"sl"` or `"en"` |
| `max_results` | Cap on how many leads to return | `100` |

### AI Qualifier Parameters *(V2)*

| Parameter | Description | Example |
|-----------|-------------|---------|
| `ideal_client_description` | Plain text description of ideal client | `"A small manufacturing company that sells locally but has no online presence"` |
| `qualification_model` | Which model to use | `"gemma"` or `"gpt-4o"` |
| `min_score` | Minimum score to include in output | `6` |

---

## Example Profile Files

### Broad — Any business with a website in Maribor
```json
{
  "name": "maribor_any_website",
  "keywords": ["podjetje", "storitve", "company", "services"],
  "locations": ["Maribor"],
  "require_website": true,
  "max_results": 200
}
```

### Niche — Wood companies Slovenia
```json
{
  "name": "slovenia_wood",
  "keywords": ["woodworking", "carpenter", "furniture", "lesarstvo", "mizar", "pohištvo"],
  "locations": ["Slovenija"],
  "require_website": false,
  "max_results": 150
}
```

### Teras AI ideal client — Small businesses needing AI
```json
{
  "name": "teras_ideal_client",
  "keywords": ["marketing agency", "consulting", "logistics", "manufacturing", "retail"],
  "locations": ["Maribor", "Ljubljana", "Celje"],
  "require_website": true,
  "min_reviews": 3,
  "max_results": 100
}
```

---

## How Profiles Are Used

1. Profile file is placed in `/profiles` folder
2. Prospector is run with profile name as argument
3. Pipeline reads the profile and passes parameters to each relevant module
4. Output file is named after the profile + timestamp

---

## Profile Design Philosophy

Profiles should be written by a human, in plain terms. They should be readable by anyone without technical knowledge. The technical translation of those parameters into actual scraper queries is handled by the Finder module — not the profile itself.

This means profiles can be written, shared, adjusted, and versioned easily. A non-technical user should be able to create a new profile by copying an existing one and changing the keywords and location.

---

## Future Profile Features

- Profile inheritance: base profile + overrides
- Profile templates: "local service business", "e-commerce", "manufacturer"
- Profile sharing: export/import profiles between Prospector instances
- UI for profile creation (V4)
