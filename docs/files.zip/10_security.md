# Prospector — Security

*Lightweight version — to be expanded if/when Prospector becomes a multi-user or hosted product.*

---

## Current Threat Model

Prospector V1 is a local tool running on a private server. The attack surface is minimal. The main risks are:

1. API keys exposed in code or version control
2. Output CSVs containing business data accessed by unintended parties
3. Server access by unauthorized users on the local network

---

## API Key Handling

- All API keys stored in `.env` file only
- `.env` is listed in `.gitignore` — never committed to version control
- Keys are never hardcoded in any source file
- When sharing code (GitHub, Cursor, etc.) — always verify `.env` is excluded

Example `.env`:
```
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=...
GOOGLE_PLACES_API_KEY=...
```

---

## Output Data

- CSV files stored in `/output/` on the server
- Access via local network only
- Do not upload output CSVs to cloud storage without reviewing contents first
- Delete CSVs when no longer needed

---

## Server Access

- Server should have a strong login password
- SSH access should use key-based authentication (not password-only) if enabled
- Prospector should not be exposed to the public internet in V1

---

## Future Security Considerations

When Prospector becomes a product:
- User authentication for any web UI
- Rate limiting on any API endpoints
- Audit log of who ran what and when
- Data encryption at rest for stored leads
- Regular dependency updates to patch vulnerabilities
