# Prospector — Testing & Quality

*Lightweight version — to be expanded as the project matures.*

---

## What "Good Output" Looks Like

A successful Prospector run produces a CSV where:
- Every row has at minimum: name, source, profile_used, found_at
- No duplicate rows (same name + address)
- Website URLs are valid format (start with http:// or https://)
- `website_live` is either `true` or `false` — never empty
- No broken encoding (special characters like š, č, ž display correctly)

---

## Manual Spot Checks (V1)

After each run, manually verify:
- [ ] Open CSV — does it load cleanly?
- [ ] Random sample of 5 rows — do the businesses exist on Google Maps?
- [ ] Random sample of 3 websites — do they actually load?
- [ ] Check for obvious duplicates
- [ ] Check lead count is reasonable for the search (not 0, not suspiciously high)

---

## Test Profiles

Maintain at least one lightweight test profile for quick validation:

```json
{
  "name": "test_run",
  "keywords": ["kavarna", "coffee"],
  "locations": ["Maribor"],
  "max_results": 10
}
```

Run this after any significant code change to confirm the pipeline still works end-to-end.

---

## Known Quality Risks

- Google Maps data quality varies — some listings are outdated or incomplete
- Website live check is a basic ping — a site may be "live" but broken or under construction
- Business categories from Google Maps are user-generated and inconsistent

---

## Future Testing Plans

- Automated unit tests for each module
- Schema validation on CSV output (confirm all required fields present and correct type)
- Regression test suite run before any new version release
- AI qualification quality checks (does the scoring make sense?)
