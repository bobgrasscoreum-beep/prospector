# Prospector — Data & Ethics Policy

## Overview

Prospector collects publicly available business information. This document outlines what data is collected, how it is handled, and the legal and ethical boundaries the system operates within.

---

## What Data Is Collected

Prospector collects only **publicly visible business information**:

- Business name
- Business address
- Phone number (if publicly listed)
- Website URL
- Google Maps rating and review count
- Business category

Prospector does **not** collect:

- Personal names of individuals
- Private email addresses
- Any data behind login walls
- Any data from private or restricted sources

---

## GDPR Considerations

Teras AI operates from Slovenia, which is an EU member state. GDPR applies.

### Key Points

**Business data vs personal data**
GDPR primarily protects personal data — information about identifiable individuals. Data about a business entity (company name, registered address, business phone) is generally not personal data under GDPR.

However, data about sole traders (self-employed individuals) where their personal name and personal phone number is the business contact — **this is personal data** and GDPR applies.

### Our Approach

- Prospector targets businesses, not individuals
- Output data should be used for legitimate B2B outreach only
- Do not use output data to contact individuals in a personal capacity
- Do not store or share output data beyond what is needed for outreach
- Delete lead data that is no longer being actively used

### Legitimate Interest Basis
B2B cold outreach to businesses can be conducted under "legitimate interest" as a lawful basis under GDPR, provided:
- The outreach is relevant to the business
- There is a clear opt-out mechanism in any communication
- Data is not retained longer than necessary

---

## Ethical Scraping Principles

**Respect robots.txt**
Prospector should check and respect robots.txt files where applicable.

**Rate limiting**
Requests are deliberately slowed. We do not hammer servers. A delay between requests is built into the scraper.

**No fake identity**
Prospector does not impersonate a human user, bypass CAPTCHAs through deceptive means, or misrepresent itself.

**No private data**
If a page requires login, Prospector does not attempt to access it.

---

## Data Storage

- All lead data is stored locally on the server
- No lead data is sent to third-party services (except AI API calls in V2, which send only the business description — not contact info)
- Output CSVs should be treated as business-sensitive files
- API keys are stored in `.env` and never committed to version control or shared

---

## When Productized

If Prospector is offered to clients:
- Client data stays with the client — Teras AI does not retain copies
- A clear terms of use document will be provided
- Clients are responsible for their own GDPR compliance in how they use the output

---

## Review Schedule

This policy should be reviewed whenever:
- A new data source is added
- The product is offered to external clients
- Significant changes to GDPR guidance occur
