# Prospector — Architecture

## Pipeline Overview

Prospector is a linear pipeline. Data flows in one direction through independent stages. Each stage has a defined input and a defined output. Stages do not talk to each other directly — they pass data forward.

```
[Target Profile]
      ↓
[Finder Module]
      ↓
[Enricher Module]
      ↓
[Qualifier Module]  ← optional, AI-powered
      ↓
[Output Module]
      ↓
[CSV / Output File]
```

---

## Stage Descriptions

### 1. Target Profile
**What it is:** A configuration file (JSON or similar) that defines what to look for.
**Input:** User-defined parameters
**Output:** Structured search instructions passed to the Finder
**Details:** See Doc 04 — Target Profile System

---

### 2. Finder Module
**What it is:** The scraper. Goes out and finds businesses matching the profile.
**Input:** Target profile (keyword, location, filters)
**Output:** Raw list of businesses with basic fields (name, address, phone, website URL if available, source)
**V1 Sources:**
- Google Maps (primary)
**Future Sources:**
- Local business directories
- Yellow Pages Slovenia
- Industry-specific sites

**Key principle:** The Finder just finds. It does not judge quality. It does not enrich. It collects.

---

### 3. Enricher Module
**What it is:** Takes raw leads and adds more information.
**Input:** Raw lead list from Finder
**Output:** Enriched lead list with additional fields
**V1 enrichment:**
- Website live check (is the URL reachable?)
- Basic metadata from website (title tag, description tag)
**Future enrichment:**
- Contact info extraction
- Tech stack detection
- Social media presence
- Last activity signals

**Key principle:** Enrichment is additive. If enrichment fails for a lead, the lead still passes through — just with empty enrichment fields.

---

### 4. Qualifier Module *(V2 — not in V1)*
**What it is:** AI-powered scoring and filtering layer.
**Input:** Enriched lead list
**Output:** Scored/tagged lead list
**Logic:** Uses local model (Gemma) or BYOK external model to assess each lead against the ideal client profile. Tags leads as hot / warm / skip or scores 1-10.
**Key principle:** AI-optional. If this module is disabled, leads pass through unscored.

---

### 5. Output Module
**What it is:** Formats and saves the final lead list.
**Input:** Processed lead list (enriched, optionally qualified)
**Output:** CSV file saved to designated output folder
**V1 format:** CSV (see Doc 05 — Output Spec)
**Future formats:** JSON, direct Lynqd import, webhook

---

## How Modules Connect

Each module reads from a defined input and writes to a defined output. In V1 this is simple: each stage processes a list and passes it to the next. The pipeline runner calls each stage in sequence.

No stage should modify another stage's data directly. If a stage fails, it logs the failure and the pipeline either stops or skips that stage depending on configuration.

---

## Execution Model

**V1:** Command line. You run Prospector manually with a profile name as the argument.
```
python prospector.py --profile maribor_wood
```

**Future:** Scheduled runs, web trigger, API endpoint.

---

## Folder Structure (Proposed)

```
/prospector
  /profiles          ← target profile config files
  /modules
    finder.py
    enricher.py
    qualifier.py     ← stub in V1
    output.py
  /output            ← generated CSV files land here
  /logs              ← run logs
  /docs              ← all 11 documentation files
  pipeline.py        ← main runner
  config.py          ← global settings
  requirements.txt
  README.md
```

---

## Technology Choices (Proposed, Cursor to Confirm)

- **Language:** Python (best ecosystem for scraping, AI, data processing)
- **Scraping:** Playwright or Selenium for Google Maps (dynamic content), requests + BeautifulSoup for static pages
- **Data handling:** pandas or plain CSV module
- **AI (V2):** Ollama local API or direct BYOK HTTP calls
- **Config files:** JSON or YAML for profiles

These are starting suggestions. Cursor should validate and adjust based on what works best in practice.
