# Prospector — Error Handling & Logging

## Philosophy

Prospector runs unattended on a server. You won't be watching it. It needs to:
- Record what happened
- Fail gracefully without losing work
- Make it easy to understand what went wrong after the fact

---

## Log Files

Every run generates a log file saved to `/logs/`.

**Naming convention:**
```
prospector_{profile_name}_{YYYY-MM-DD_HH-MM}.log
```

**Log levels:**
- `INFO` — normal operation ("Found 47 results", "Website check complete")
- `WARNING` — something unexpected but recoverable ("Website unreachable, skipping enrichment")
- `ERROR` — something failed but pipeline continued ("Failed to parse 3 listings, skipped")
- `CRITICAL` — pipeline stopped ("Google Maps blocked request after 50 results")

---

## Run Summary

At the end of every run, Prospector prints and logs a summary:

```
--- Prospector Run Summary ---
Profile:        maribor_wood
Started:        2025-05-18 14:32:00
Finished:       2025-05-18 14:47:23
Duration:       15m 23s

Finder:         83 businesses found
Enricher:       79 websites checked (4 skipped - no URL)
                71 websites live, 8 unreachable
Qualifier:      Skipped (not enabled)
Output:         79 leads written to CSV

Errors:         2 warnings, 0 errors
Output file:    /output/prospector_maribor_wood_2025-05-18_14-32.csv
------------------------------
```

---

## Error Handling by Stage

### Finder
- If Google Maps returns no results: log warning, end run cleanly, output empty CSV with header
- If Google Maps blocks the request mid-run: log critical, save partial results found so far, stop
- If network is unavailable: log critical, stop immediately

### Enricher
- If a website is unreachable: log info, mark `website_live = false`, continue
- If website returns error (404, 500, etc.): log info, mark accordingly, continue
- If enrichment takes too long (timeout): log warning, skip enrichment for that lead, continue

### Qualifier (V2)
- If AI model is unavailable: log critical, skip qualification entirely, output unscored leads
- If AI returns unparseable response: log warning, leave score empty for that lead, continue

### Output
- If output directory doesn't exist: create it automatically
- If file write fails: log critical, attempt to write to fallback location (`/tmp/`)

---

## Partial Saves

If a run is interrupted mid-way, Prospector should save whatever it has found so far. A partial output is better than no output. The log will indicate the run was incomplete.

---

## Log Retention

Logs older than 30 days are automatically deleted to prevent disk fill.
Output CSVs are kept until manually deleted.

---

## Future: Run History

In a later version, a simple run history file (`run_history.json`) will track:
- All runs with timestamps
- Profile used
- Lead count
- Success/failure status

This enables a dashboard view of pipeline health over time.
