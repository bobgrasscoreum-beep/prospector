# Prospector — Project Overview

## What Is Prospector?

Prospector is a modular, self-hosted lead generation pipeline. It finds businesses, gathers basic information about them, and produces clean, structured output ready for outreach.

It runs on your own hardware. It costs nothing to operate. It does not depend on any third-party platform to function at its core.

The name fits: it goes out, searches the terrain, and brings back what's worth looking at.

---

## Why It Exists

Teras AI needs a repeatable way to find potential clients. Manual searching is slow, inconsistent, and doesn't scale. Hiring someone to do it is premature. Existing tools are expensive, cloud-dependent, or built for large sales teams.

Prospector is built for a solo operator who wants a quiet, reliable machine running in the background — finding leads while they focus on everything else.

---

## Core Principles

**Modular**
Every stage of the pipeline is independent. The part that finds businesses doesn't care how they'll be qualified. The part that qualifies them doesn't care where they were found. You can swap, upgrade, or disable any stage without rebuilding the rest.

**Local-first**
Prospector runs on your server. Data doesn't leave your network unless you choose to send it somewhere. No subscriptions. No usage limits. No vendor dependency.

**AI-optional**
The core pipeline works without any AI model. A script that finds every business with a website in Maribor should work without calling an API. AI is a layer you add on top when you want richer qualification — not a requirement to get started.

**Low running cost**
V1 should cost nothing beyond electricity. As the system grows, any AI features use bring-your-own-key (BYOK) so you control what you spend and with which provider.

**Expandable**
Everything built now should be easy to extend later. New data sources, new qualification logic, new output formats — none of these should require rewriting what already works.

---

## What Prospector Is Not

- It is not a CRM
- It is not an outreach tool (that's Lynqd)
- It is not a real-time monitoring system
- It is not a service that runs in the cloud

---

## The Bigger Picture

Prospector feeds Lynqd. Lynqd generates the outreach. Together they form a complete cold outreach pipeline — from finding a business to sending a personalized email and proposal PDF.

Phase 1: Prospector runs standalone, outputs CSV.
Phase 2: Prospector output connects directly to Lynqd input.
Phase 3: Prospector becomes a product offered to other consultants and agencies.

---

## Who Built This

Jernej Teraš / Teras AI — Maribor, Slovenia.
Built as an internal tool first. Productized if it proves its value.
