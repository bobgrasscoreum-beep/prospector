# Prospector — Output Specification

## Output Format: CSV

V1 output is a single CSV file. One row per business. Clean headers. No special characters that would break import.

---

## V1 Fields

| Field | Description | Example | Required |
|-------|-------------|---------|----------|
| `id` | Unique row identifier | `PRO-0001` | Yes |
| `name` | Business name | `Mizar Kovač d.o.o.` | Yes |
| `category` | Business category from source | `Woodworking` | If available |
| `address` | Full address | `Ulica 14, 2000 Maribor` | If available |
| `city` | City | `Maribor` | If available |
| `country` | Country | `Slovenia` | Yes |
| `phone` | Phone number | `+386 2 123 4567` | If available |
| `website` | Website URL | `https://kovac-mizar.si` | If available |
| `website_live` | Is website reachable? | `true` / `false` | Yes |
| `google_maps_url` | Direct link to Maps listing | `https://maps.google.com/...` | If available |
| `rating` | Google Maps rating | `4.2` | If available |
| `review_count` | Number of reviews | `17` | If available |
| `source` | Where this lead was found | `google_maps` | Yes |
| `profile_used` | Which profile generated this | `slovenia_wood` | Yes |
| `found_at` | Timestamp of discovery | `2025-05-18T14:32:00` | Yes |
| `notes` | Any flags or manual notes | `` | No |

---

## V2 Additional Fields (AI Qualification)

| Field | Description | Example |
|-------|-------------|---------|
| `ai_score` | Qualification score 1-10 | `7` |
| `ai_tag` | Hot / Warm / Skip | `warm` |
| `ai_reasoning` | Why this score was given | `"Small local manufacturer, no apparent digital presence"` |
| `website_summary` | AI summary of what they do | `"Custom wooden furniture, family business, Est. 1998"` |

---

## File Naming Convention

```
prospector_{profile_name}_{YYYY-MM-DD_HH-MM}.csv
```

Example:
```
prospector_slovenia_wood_2025-05-18_14-32.csv
```

---

## Output Location

All CSV files are saved to `/output` folder in the Prospector root directory.

---

## Lynqd Compatibility

When Prospector connects to Lynqd (V3), the CSV fields must map cleanly to Lynqd's client input fields. The fields listed above are designed with that compatibility in mind. The key fields Lynqd needs:

- `name` → Client name
- `website` → Client website
- `phone` → Contact phone
- `address` / `city` → Location context
- `category` → Business type (helps Lynqd select relevant service presets)

Any field Lynqd doesn't use will simply be ignored on import.

---

## Data Quality Rules

- Empty fields are left blank — never filled with placeholder text like "N/A" or "unknown"
- URLs always include protocol (`https://` or `http://`)
- Phone numbers kept as-is from source — no reformatting in V1
- Duplicate businesses (same name + address) should be removed before output
- Encoding: UTF-8 always
