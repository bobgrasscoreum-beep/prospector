# Prospector — Changelog

*This file is updated by Cursor after every meaningful change. Each entry should include the version, date, and a plain-English description of what changed and why.*

---

## Format

```
## [version] — YYYY-MM-DD
### Added
- New features or files added

### Changed
- Modifications to existing functionality

### Fixed
- Bug fixes

### Removed
- Anything deleted or deprecated

### Notes
- Context, decisions made, things to remember
```

---

## [0.1.0] — 2025-05-18

### Added
- Initial project documentation (11 files)
- Project structure defined
- Architecture designed
- Target profile system designed
- Output CSV spec defined

### Notes
- Project initiated. Documentation-first approach before any code is written.
- Building will begin in Cursor using this documentation as full context.
- V1 goal: working pipeline that finds businesses via Google Maps and outputs clean CSV.
