# Prospector — Product Scope & Roadmap

## V1 — The Working Pipeline

### In Scope

- Google Maps scraper: finds businesses by keyword + location
- Website checker: confirms whether a business has a working website
- Target Profile system: configurable search parameters (keyword, location, filters)
- CSV output: clean, structured, ready for manual import into Lynqd
- Local execution: runs on server via command line or simple trigger
- Basic logging: records what ran, when, how many results

### Explicitly Out of Scope for V1

- AI qualification (comes in V2)
- LinkedIn scraping
- Automated scheduling / cron jobs (manual trigger only)
- Direct Lynqd integration
- Web UI or dashboard
- Email verification
- Any cloud deployment

### Definition of V1 Done

You can run Prospector with a target profile (e.g. "wood companies, Maribor"), it finds businesses from Google Maps, checks for websites, and outputs a clean CSV with the results. No errors. No manual cleanup needed.

---

## V2 — AI Qualification Layer

- Plug in local Gemma model or BYOK external model
- Analyze each lead: does this business match the ideal client profile?
- Score or tag leads (hot / warm / skip)
- Enrichment: pull basic info from their website (what they do, contact info, tech stack hints)
- Still outputs CSV, now with qualification columns added

---

## V3 — Expanded Sources & Automation

- Additional scrapers: Yellow Pages, local business directories, industry-specific sites
- Scheduled runs: define a profile, set a schedule, leads appear automatically
- Duplicate detection: don't surface the same business twice
- Direct Lynqd integration: output feeds directly into Lynqd client list

---

## V4 — Product Mode

- Simple web UI for non-technical users
- Profile management through interface (not just config files)
- Multi-user support
- Packaged for sale or white-label to other agencies

---

## Parked Ideas (No Version Assigned Yet)

- LinkedIn integration (requires careful approach — heavily protected)
- Email finding and verification
- Social signal detection (is this business active? when did they last post?)
- CRM sync (HubSpot, Notion, Airtable)
- Webhook output (trigger Lynqd automatically when new leads arrive)

---

## Scope Discipline

When building, if a feature isn't listed in the current version scope — park it. Add it to the parked list. Don't build it now. The goal of each version is a working, stable, useful thing — not a complete thing.
