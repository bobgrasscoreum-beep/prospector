# Prospector — Deployment Context

## Hardware

### Server PC (Primary Deployment Target)
- **CPU:** Intel i7
- **RAM:** 16GB (upgrading to 32GB)
- **GPU:** NVIDIA RTX 2070 Super
- **Role:** Runs Prospector, hosts local AI models (Gemma 4B via Ollama), handles background processing
- **OS:** To be confirmed (Linux preferred for server use)

### Main PC (Development)
- **CPU:** Intel i9
- **RAM:** 32GB (upgrading to 64GB)
- **GPU:** NVIDIA RTX 3080
- **Setup:** 3-monitor workstation
- **Role:** Development, Cursor, testing, review of output

---

## Deployment Model

Prospector runs locally on the server PC. It is not deployed to any cloud service. It does not require an internet-facing server. It runs when triggered and stops when done.

**V1 execution:** Manual trigger via command line
**Future:** Scheduled execution, possible local web trigger

---

## How to Run (V1)

```bash
# Navigate to Prospector directory
cd /path/to/prospector

# Run with a specific profile
python pipeline.py --profile maribor_wood

# Run with max results override
python pipeline.py --profile maribor_wood --max 50

# Run in dry mode (no output saved, just logs)
python pipeline.py --profile maribor_wood --dry-run
```

---

## Environment Setup

### Python Environment
- Python 3.10+
- Virtual environment recommended (`venv`)
- Dependencies in `requirements.txt`

### Required Installations
- Python 3.10+
- pip
- Playwright (for browser-based scraping) — requires additional browser install step
- Ollama (for V2 local AI) — already on server for Gemma

### First-Time Setup
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt

# Install Playwright browsers
playwright install chromium
```

---

## Configuration

Global settings live in `config.py` or a `.env` file:

```
OUTPUT_DIR=./output
LOG_DIR=./logs
DEFAULT_MAX_RESULTS=100
HEADLESS=true
REQUEST_DELAY=2
```

API keys (for V2 BYOK) stored in `.env` — never committed to version control.

---

## Network Considerations

- Prospector makes outbound HTTP requests to Google Maps and target websites
- No inbound connections required in V1
- Rate limiting built in (delay between requests) to avoid blocks
- If running on home network: standard residential IP — may need rotation for large runs in future

---

## Accessing Output

Output CSV files are saved to `/prospector/output/` on the server.

From the main PC, access via:
- Local network share
- SSH/SFTP
- Shared folder (depending on server OS setup)

---

## Future Deployment Considerations

- Simple local web UI to trigger runs and view output (V4)
- Possible Docker containerization for easier deployment to client servers
- If productized: cloud deployment option with user authentication
